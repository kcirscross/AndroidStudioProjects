package com.example.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MonAnNgonAdapter extends RecyclerView.Adapter<MonAnNgonAdapter.ViewHolder> {
    ArrayList<MonAnNgon> dataMonAn;
    Context context;

    public MonAnNgonAdapter(ArrayList<MonAnNgon> dataMonAn, Context context) {
        this.dataMonAn = dataMonAn;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View itemView = layoutInflater.inflate(R.layout.activity_mon_an,parent,false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.txtName.setText(dataMonAn.get(position).getTen());
        holder.img.setImageResource(dataMonAn.get(position).getHinhAnh());
    }

    @Override
    public int getItemCount() {
        return dataMonAn.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView txtName;
        ImageView img;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtName = (TextView)itemView.findViewById(R.id.textView);
            img = (ImageView)itemView.findViewById(R.id.imageView);
        }
    }
}
