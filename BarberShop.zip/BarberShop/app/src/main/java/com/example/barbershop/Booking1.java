package com.example.barbershop;

public class Booking1 {
    private String day;

    public Booking1(String day) {
        this.day = day;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }
}
