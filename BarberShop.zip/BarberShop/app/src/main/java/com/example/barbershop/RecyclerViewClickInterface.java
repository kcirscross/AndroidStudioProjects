package com.example.barbershop;

public interface RecyclerViewClickInterface {
    void onItemClick(int position);
    void onItemClick2(int position);
}
