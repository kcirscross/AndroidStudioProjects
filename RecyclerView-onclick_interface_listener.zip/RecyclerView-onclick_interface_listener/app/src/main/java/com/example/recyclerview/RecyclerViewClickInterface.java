package com.example.recyclerview;

public interface RecyclerViewClickInterface {
    void onItemClick(int position);
    void onLongItemClick(int position);
}
